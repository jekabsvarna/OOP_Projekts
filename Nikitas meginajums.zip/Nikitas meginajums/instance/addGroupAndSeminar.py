import sqlite3
from datetime import datetime

# Connect to the SQLite database
conn = sqlite3.connect('database.db')
cur = conn.cursor()

# Create the seminar table
try:
    cur.execute('''
    CREATE TABLE seminar (
        id INTEGER PRIMARY KEY,
        title VARCHAR(150) NOT NULL UNIQUE,
        description TEXT NOT NULL,
        date_time TEXT NOT NULL,  -- SQLite does not have a DATETIME type
        lecturer_id INTEGER,
        FOREIGN KEY (lecturer_id) REFERENCES user(id)
    );
    ''')
    print('Created seminar table!')
except sqlite3.OperationalError:
    print('Seminar table already exists.')

# Create the group table (note: 'group' is a reserved word, so we'll use 'group_table')
try:
    cur.execute('''
    CREATE TABLE group_table (
        id INTEGER PRIMARY KEY,
        name VARCHAR(150) NOT NULL,
        seminar_id INTEGER,
        FOREIGN KEY (seminar_id) REFERENCES seminar(id)
    );
    ''')
    print('Created group table!')
except sqlite3.OperationalError:
    print('Group table already exists.')

# Example seminars with date and time
seminars = [
    ("Advanced Databases", "Exploring the depths of database systems.", datetime.utcnow().isoformat(), 1),
    ("Machine Learning", "An introduction to machine learning concepts.", datetime.utcnow().isoformat(), 2),
]

# Insert seminars into the database
for title, description, date_time, lecturer_id in seminars:
    try:
        cur.execute("INSERT INTO seminar (title, description, date_time, lecturer_id) VALUES (?, ?, ?, ?)",
                    (title, description, date_time, lecturer_id))
        print(f"Added seminar: {title}")
    except sqlite3.IntegrityError as e:
        print(f"Error adding seminar: {e}")

# Example groups for the first seminar
groups = [
    ("Group A", 1),  # Assuming the first seminar has ID 1
    ("Group B", 1),
]

# Insert groups into the database
for name, seminar_id in groups:
    try:
        cur.execute("INSERT INTO group_table (name, seminar_id) VALUES (?, ?)",
                    (name, seminar_id))
        print(f"Added group: {name}")
    except sqlite3.IntegrityError as e:
        print(f"Error adding group: {e}")

# Commit changes and close the connection
conn.commit()
conn.close()

print("Finished setting up the database with seminars and groups.")
