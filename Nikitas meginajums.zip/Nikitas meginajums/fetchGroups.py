import sqlite3

def get_groups(db_path, limit=10, offset=0):
    # Connect to the SQLite database
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    # Query to select all groups with pagination
    query = "SELECT id, name, seminar_id FROM `group` LIMIT ? OFFSET ?"

    # Execute the query with limit and offset parameters
    cur.execute(query, (limit, offset))

    # Fetch all results within the limit and offset
    groups = cur.fetchall()

    # Close the connection
    conn.close()

    return groups

def get_total_groups_count(db_path):
    # Connect to the SQLite database
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    # Query to count all groups
    query = "SELECT COUNT(*) FROM `group`"  

    # Execute the query
    cur.execute(query)

    # Fetch one result
    count = cur.fetchone()[0]

    # Close the connection
    conn.close()

    return count
