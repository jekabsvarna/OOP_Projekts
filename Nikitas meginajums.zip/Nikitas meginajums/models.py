from . import db
from flask_login import UserMixin
from sqlalchemy.sql import func
from flask_migrate import Migrate
from datetime import datetime
from flask_wtf import FlaskForm
from wtforms import SelectMultipleField, StringField, SubmitField
from wtforms.validators import DataRequired

group_member = db.Table('group_members',
    db.Column('user_id', db.Integer, db.ForeignKey('user.id'), primary_key=True),
    db.Column('group_id', db.Integer, db.ForeignKey('group.id'), primary_key=True)
)


class AssignStudentsForm(FlaskForm):
    students = SelectMultipleField('Students', choices=[], coerce=int)  # Choices need to be populated in the route
    submit = SubmitField('Assign')

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True)
    password = db.Column(db.String(150))
    first_name = db.Column(db.String(150))
    role = db.Column(db.String(10), default='student')  # Possible values: admin, lecturer, student
    groups = db.relationship('Group', secondary=group_member, backref=db.backref('user_groups', lazy='dynamic'))

class Article(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(255), nullable=False)

class Seminar(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(150), nullable=False)
    description = db.Column(db.String(1000), nullable=True)
    lecturer = db.Column(db.String(250))
    groups = db.relationship('Group', backref='seminar', lazy='dynamic')

group_member = db.Table('group_member',
    db.Column('group_id', db.Integer, db.ForeignKey('group.id'), primary_key=True),
    db.Column('user_id', db.Integer, db.ForeignKey('user.id'), primary_key=True)
)

class Group(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    name = db.Column(db.String(100), nullable=False)
    seminar_id = db.Column(db.Integer, db.ForeignKey('seminar.id'), nullable=False)
    # member_count seems like it should be a simple column, not a relationship
    members = db.relationship('User', secondary=group_member, lazy='dynamic')