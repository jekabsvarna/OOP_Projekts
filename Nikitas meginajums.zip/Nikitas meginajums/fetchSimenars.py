import sqlite3

def get_seminars(db_path, limit=10, offset=0):
    # Connect to the SQLite database
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    # Query to select all seminars with pagination
    query = "SELECT id, title, description, lecturer FROM seminar LIMIT ? OFFSET ?"

    # Execute the query with limit and offset parameters
    cur.execute(query, (limit, offset))

    # Fetch all results within the limit and offset
    seminars = cur.fetchall()

    # Close the connection
    conn.close()

    return seminars

def get_total_seminars_count(db_path):
    # Connect to the SQLite database
    conn = sqlite3.connect(db_path)
    cur = conn.cursor()

    # Query to count all seminars
    query = "SELECT COUNT(*) FROM seminar"  

    # Execute the query
    cur.execute(query)

    # Fetch one result
    count = cur.fetchone()[0]

    # Close the connection
    conn.close()

    return count
