# app.py

from flask import Flask, render_template, request, redirect, url_for
from flask_sqlalchemy import SQLAlchemy
from flask_wtf import FlaskForm
from wtforms import StringField, SubmitField
from wtforms.validators import DataRequired
from flask import Flask
from views import views  # Adjust the import path as necessary

app = Flask(__name__)
app.register_blueprint(views)
app.config['SQLALCHEMY_DATABASE_URI'] = 'sqlite:///seminars.db'
app.config['SECRET_KEY'] = 'a very secret key'
app.config['SQLALCHEMY_TRACK_MODIFICATIONS'] = False

db = SQLAlchemy(app)



# Continuing in app.py

class Seminar(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    title = db.Column(db.String(80), nullable=False)

    def __repr__(self):
        return f'<Seminar {self.title}>'

# Continuing in app.py

class SeminarForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    submit = SubmitField('Add Seminar')

# Continuing in app.py

@app.route('/add_seminar', methods=['GET', 'POST'])
def add_seminar():
    form = SeminarForm()
    if form.validate_on_submit():
        seminar = Seminar(title=form.title.data, description=form.description.data)
        db.session.add(seminar)
        db.session.commit()
        return redirect(url_for('index'))
    return render_template('add_seminar.html', form=form)

@app.route('/')
def index():
    seminars = Seminar.query.all()
    return render_template('index.html', seminars=seminars)
