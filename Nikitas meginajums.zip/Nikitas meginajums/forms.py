from flask_wtf import FlaskForm
from wtforms import SelectMultipleField, StringField, SubmitField, TextAreaField, SelectField
from wtforms.validators import DataRequired

class SeminarForm(FlaskForm):
    title = StringField('Title', validators=[DataRequired()])
    description = TextAreaField('Description', validators=[DataRequired()])
    lecturer = StringField('Lecturer', validators=[DataRequired()])
    submit = SubmitField('Submit')

class GroupForm(FlaskForm):
    name = StringField('Group Name', validators=[DataRequired()])
    seminar_id = SelectField('Seminar', coerce=int, validators=[DataRequired()])
    # students = SelectMultipleField('Students', coerce=int)
    submit = SubmitField('Add Group')




class AssignStudentsForm(FlaskForm):
    user_id = SelectMultipleField('Students', coerce=int, validators=[DataRequired()])
    submit = SubmitField('Assign to Group')